DIAGNOSTIC - NOT QUALIFIED
64-bit Raspberry Pi OS, CPython 3.12. Install OS libsndfile and PortAudio for microphone input.
python3 -m venv .venv
.venv/bin/python -m pip install --require-hashes --only-binary=:all: -r requirements.txt
.venv/bin/python -m vcm.tui --bundle models/selected --wav /path/to/mono.wav
.venv/bin/python -m vcm.tui --bundle models/selected --mic DEVICE_INDEX
Setup needs network unless dependencies are preinstalled. Recognition makes no network calls.
Training corpus and PyTorch are excluded. No device actions. Physical Pi/microphone verification is separate.
FSC-derived academic research artifact; see MODEL_CARD.md for restrictions and coverage.
