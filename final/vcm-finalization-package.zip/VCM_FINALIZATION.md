# Smart-speaker finalization audit and test-service package

**Audit date:** 15 October 2026, project time zone UTC+08:00.  
**Source examined:** `justinruaya123/smart-speaker`, `codex/vcm-intent-slots-v1`,
`5be3a7f5f5ac38ba6c4fcc14d7fd99de478b0bbd`.  
**Verdict:** test-service changes implemented and fixture-verified; final model,
live ownership, physical Pi and submission qualification remain **BLOCKED**.

The user reports that final training is now on the A100 cluster. This session did
not attach to that job, inspect its live process, obtain its final checkpoint, or
read its uncommitted datasets. Historical failures below are not measurements of
that running A100 candidate. No running job, installed model, provider, remote
branch, repository visibility or license was modified. The attached source patch
has not been installed in the cluster checkout or published to GitHub.

## 1. What was completed here

The original `scripts/runtime/speaker_worker.py` was retrieved through the connected
GitHub repository and reconstructed byte-for-byte. Its Git blob identity was
verified as `944ce510fbe14254ebd72362d11c1987ecd5eead` before modification.

The experimental flag previously required a one-shot `--wav`. It can now also run
as a resident, action-free JSONL command-WAV service. It reuses the existing
`IntentSlotsRuntime` and authoritative `final_application`; no additional command
model, formatter, transcript path or confidence policy was introduced.

The changes provide repeated WAV requests with one model load, `status`, request
correlation, actual candidate checkpoint/contract identities, actual 0.95/0.90
threshold reporting, and explicit `command_only=true`, `owner_enforced=false`,
`qualification_verified=false`. Microphone/wake operations and unexpected control
fields, including expected labels, reject. Candidate audio remains 16 kHz mono,
400..128,000 samples; the legacy WAV path retains its existing duration behavior.
Actions remain disabled even when the ordinary configuration enables them.

A concurrency regression was also reproduced and fixed: a malformed JSON line
received while a WAV was being processed inherited that WAV's request ID. Candidate
reader faults now enter the queue and are emitted by the service thread rather
than being misattributed from the reader thread.

`scripts/test/vcm_resident_smoke.py` exercises the real resident worker process
with supplied WAV files. It verifies one loaded session, request accounting,
identities, thresholds, final/application agreement and disabled actions. It writes
immutable run identity, event trace, stderr and a result under
`.cache/vcm-final-readiness-v1/<run-id>/`. It never receives expected labels and
never reports service success as acoustic accuracy or physical-Pi qualification.
A failed request, startup failure, incomplete trace or identity mismatch fails it.

**Executed verification:** 49 tests passed in the available isolated source
snapshot. Tests use real PCM-16 WAV encoding/decoding and the real worker/control
loop, but recognizer doubles for inference. They are not human speech, trained
model, ncnn-kernel or hardware measurements. Three red-to-green cycles cover the
resident service, smoke verifier and reader-fault attribution. Syntax compilation
and patch whitespace checks passed. No dependencies were installed. No full
repository regression or independent second-agent review is claimed.

The local environment was Python 3.13.5, Torch 2.10.0+cpu, NumPy 2.3.5, pytest
9.0.2, soundfile 0.13.1 and einops 0.8.2. ONNX, ONNX Runtime and ncnn were not
installed here. `verification.json` records the exact interpreter string and file
hashes; it is the authority if a prose version differs.

## 2. Freeze the existing architecture, not the slide placeholders

The implementation/specification agree on complete-utterance processing:

`16 kHz mono PCM -> existing 40-bin log-mel -> width-128 temporal CNN -> intent,
role-state, finite-value, request-validity and entity heads -> typed accept/reject`.

The stem uses stride two and symmetric padding. Eight residual temporal blocks
use dilations 1,2,4,8,1,2,4,8. Pooling sees the valid completed utterance. The
committed parameter count is 280,818; the intent head has 19 outputs including
OOV, with 15 role queries and five 64-dimensional entity projections. Preserve the
existing 400-sample window, 160-sample hop, FFT 512, frontend details and train-only
normalization. No architecture/optimizer source was changed in this package.

The second supplied slide's causal-encoder/KV-cache labels do **not** describe
this model. The images alone do not establish whether causal operation is a hard
grading requirement. If it is mandatory, this is an unresolved rubric-compliance
gap, not permission to relabel the current implementation or silently change it. Always-on capture/wake handling is distinct from incremental neural
inference. Use “complete-utterance temporal CNN with role-query pooling,” not
“causal streaming encoder,” in the submitted model description. The loss is the
implemented masked joint classification/entity/localization objective, not an
invented CTC objective. The primary application engine remains ncnn; report ORT
separately rather than copying the template's ORT runtime field as the default.

Keep all 414 generated case definitions, 1,031 selected catalog entries, 93 OptionB
verbatims and the existing personal extensions. These are different inventories,
not interchangeable counts. Keep absolute-volume cases, exact typed outputs,
default provenance and the absent `playlist_id` field. Do not rewrite grammar or
expected phrases to fit the training data.

**Sources:** `docs/SPEC-vcm-intent-slots-v1.md`,
`experiments/vcm-intent-slots-v1/protocol.json`,
`scripts/models/vcm_intent_slots.py`,
`scripts/runtime/vcm_intent_slots_contract.py` at the pinned source.

## 3. Data sanity: historical evidence versus the current A100 inputs

The committed audio audit covered 6,975 recordings: 1,895 training, 256 development,
210 calibration, 4,418 historical test and 196 historical holdout. Feature preparation
used train/development speech; normalization used 553,467 training frames only.
Those counts and checks are historical receipts, not a fresh re-audit in this session.

The last committed complete-command comparison stopped before fitting. Training
lacked MESSAGE; development lacked CALL and MESSAGE; calibration lacked CALL,
MESSAGE, LIST_REMINDERS, TEMPERATURE and CREATE_REMINDER. Reviewed role-state,
request-validity, connected acoustic constituents/spans and full selected-entity
enrollment were also incomplete. An A100 allocation cannot supply missing labels.

The current job must bind its **actual** updated views and source receipts before
these blockers can be marked resolved. Do not assume another agent's uncommitted
preparation is represented by the remote branch. Preserve the original recordings
and review exclusions. Inspect WAV and decoded-PCM hashes, source revisions,
license/access terms, sample rate/channel count, finite PCM, corruption, clipping,
silence, duration, actual speech and duplicate/alias groups. Human listening and
near-duplicate identity review cannot be replaced by a successful file hash.

Audit coverage by exact phrase, typed command, intent, supplied slot/value, role
state, validity, person, source and condition. Keep unknown labels masked. Timer
seconds or a canonical alarm time do not establish the spoken amount/unit or
hour/minute/meridiem constituents. An isolated numeral is not a brightness command.
A role name occurring once is not evidence of adequate supervision for that role.
Record actual effective loss denominators, including entity pairs and spans.

Keep train, development, calibration, entity enrollment and fresh evaluation people,
recordings, PCM duplicates, resolved aliases and capture groups appropriately
separated. In particular, the fitting enrollment helper's train/development checks
are not a complete cross-partition enrollment-versus-calibration/final-test audit.
Do not count synthetic voices as real participants or infer gender from sound/names.
The historical supplied demographics cover only 87/337 declared human IDs: 44
female, 43 male and 250 unknown. Preserve unknown and other supplied categories.

Historical source restrictions remain: MLEnd category fitting does not supervise
complete commands; the Drive archive's old TRAIN directories contain reserved
speech; the Filipino supplement is synthetic; unresolved SNIPS access/annotations
are not newly recovered evidence. Do not import these as shortcuts around the
frozen human-only comparison.

**Sources:** `scripts/train/vcm_intent_slots_data.py`,
`scripts/train/vcm_intent_slots_train.py`, the uploaded current handoff,
`docs/EXPERIMENT-vcm-intent-slots-v1.md` and its linked coverage/source receipts.

## 4. A100 execution checks without interrupting the running job

First capture the running job's actual source/tree and permitted dirty-diff
provenance, entry command, input/protocol hashes, environment and allocation.
Record node, scheduler/job ID when applicable, GPU model/count/IDs, CUDA visibility,
Torch/CUDA/cuDNN/driver versions, seed, arm, start/end time, actual wall clock,
optimizer update count, exit state, logs and selected-checkpoint hash. An allocated
GPU, a submitted job or a CUDA-capable login shell is not proof that this particular
training process executed on the GPU.

The committed CLI defaults to CPU; CUDA fitting requires `--device cuda`. Do not
restart a healthy job or overwrite its environment just to alter this argument.
Inspect what was actually launched and record a mismatch as such. Do not install a
new Torch build into the active root environment without the required approval.
A CUDA check must use the job's interpreter/environment rather than a convenient
unrelated Python. Read-only example:

```sh
"$VCM_PY" - <<'PY'
import json
import torch

print(json.dumps({
    "torch": torch.__version__,
    "compiled_cuda": torch.version.cuda,
    "cuda_available": torch.cuda.is_available(),
    "visible_gpu_count": torch.cuda.device_count(),
    "visible_gpu_names": [
        torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())
    ],
}, indent=2))
PY
```

Keep the matched uniform/balanced comparison at seeds 53/71/89, AdamW 0.001,
weight decay 0.0001, clipping 1, batch 64, 30 x 96 updates. The 184,320 sample
presentations amount to approximately 97 per recording at the old training-set
size; log exposure and learning curves rather than equating more updates with
better generalization. Select on development and retain the earlier epoch on ties.
Do not select the arm, seed or checkpoint using final-test performance. Do not
silently introduce AMP, DDP, a different global batch, synthetic data, augmentation,
VTLP or whole-command contrastive loss into the matched recipe.

Record precision and deterministic settings consistently across compared runs.
PyTorch documents that matching seeds do not guarantee CPU/GPU or cross-version
identity; deterministic mode can raise errors for unsupported operations. Treat a
CUDA failure as a recorded failure, not permission to disable safeguards silently.

The committed selected checkpoint is not a full exact-resume checkpoint: optimizer
state and complete random-state/sampler continuation are not saved by the inspected
trainer. Do not claim preemption-resumable equivalence from weights alone. Preserve
a running job; add/test versioned recovery machinery separately before relying on
future restarts. PyTorch's checkpoint recipe explicitly includes optimizer state.

The existing `preflight` is diagnostic: it returns JSON with blockers and contains
static missing-evidence entries. Exit zero alone is **not** a final-readiness pass.
Inspect its evidence, the actual audited views and stage-specific prerequisites.
This package does not relabel that diagnostic as a reliable final green gate.

**Sources:** the pinned CLI/trainer; official PyTorch reproducibility,
`torch.use_deterministic_algorithms` and general-checkpoint documentation. On Slurm
systems, the official `sbatch` documentation defines job/node/GPU allocation
variables; no assumption is made that this cluster necessarily uses Slurm.

## 5. Close the selected-checkpoint -> enrollment -> calibration -> export gap

Development enrollment binds its encoder using an in-memory weight digest and
normalization using a structured-value digest. Export/runtime require the selected
checkpoint **file SHA-256** and the actual serialized `normalization.json` **file
SHA-256**. Therefore, a development memory cannot simply be renamed or relabeled
as final enrollment. The inspected CLI has no final `enroll` subcommand.

After checkpoint selection, use the approved acoustic enrollment implementation to
re-encode the authorized enrollment recordings with that exact selected model and
frontend/normalization. Bind those actual final file identities, retain original
recording/person provenance, rebuild the selected entity memory and matching policy,
and audit competition and separation. The complete catalog remains authoritative;
1,031 catalog entries must not be mistaken for 1,031 distinct enrollment entities.
Do not hand-edit immutable memory/calibration IDs to suppress a binding error.

Then: raw export -> independent human calibration -> frozen calibrated export ->
actual PCM tensor/final-decision parity on PyTorch/ORT/ncnn -> existing complete
selection lock -> fresh evaluation. A changed model, frontend, normalization,
entity memory or catalog requires the applicable rebuilding/recalibration and new
bindings. Calibration must have all required intent classes and the required
slot/provenance/score-shape coverage; entirely unobserved groups must not disappear
from the coverage report just because the fitter only iterated observed groups.

Preserve 0.95 intent and 0.90 for every supplied slot. Unknown named targets cannot
fall back to generic defaults. A high entity or numeric score cannot rescue a
rejected intent. Empty/singleton/expanded catalogs, absolute rejection and competing
entity margins remain tested. A memory designed for content cannot establish
speaker identity.

**Sources:** `scripts/train/vcm_intent_slots_train.py`,
`scripts/train/vcm_intent_slots_export.py`,
`scripts/train/vcm_intent_slots_calibration.py`,
`scripts/runtime/vcm_intent_slots_bindings.py` and the existing evaluation lock.

## 6. Final testing and promotion

`final-test-contract.json` preserves the existing thresholds and pilot targets,
while leaving unapproved participant counts, coverage minima and physical-Pi limits
null. It is **not locked** and must not be represented as a completed final protocol.
Bind those parameters before collecting/scoring the final suite.

Use one frozen model/policy across genuinely unseen people. Cover every preserved
OptionB verbatim and personal definition, different numeric values and targets,
negatives, malformed/conflicting/ambiguous requests, and supplied condition strata.
Independent reviewed expected outputs belong only to the offline scorer, never to
the worker. Previously examined recordings remain historical regression.

Accepted exact-command recall counts supported rejections, faults and missing
outcomes as failures. Accepted precision is undefined with zero accepted commands,
not 100%. Keep negative false accepts, capture faults, ambiguous references, all
supplied-slot denominators, human/synthetic tracks and OptionB/extension tracks
separate. Report macro-person and adequately covered worst-person results with
person-aware uncertainty; freeze adequate coverage before scoring.

Command-only tests and wake-owner tests are different tracks. The new service is
only the former. An owner-aware session requires genuine paired wake/command audio,
a separately validated identity/overlap/coverage backend, impostors, speaker changes
inside slots, short/silent references, overlap, timeout, rearm and discontinuity.
One wake permits one command. Missing evidence rejects; owner evidence cannot rescue
a command rejected by the VCM. No ownership or live microphone result was generated
in this session.

On an authorized physical Pi4, measure actual ncnn execution, cold model load,
warm inference, frontend/decision time, endpoint wait and end-of-speech-to-final
latency separately. Record p50/p95, duration/RTF, threads, RSS, CPU, temperature,
throttling, hardware/OS/audio device and observed network-independent operation.
Run a separately specified soak test and live microphone/wake/VAD/application
integration after their prerequisites. The smoke runner's host process wall time
is not model p95, end-of-speech latency or a complete Pi qualification result.

The fixed pilot goals remain 0.95 human accepted exact recall, 0.99 accepted
precision, 0.90 adequately covered worst-person recall, at most 0.01 wrong-speaker
acceptance and 0.95 genuine retention. They are not evidence of achievement or
necessarily the official assignment's numeric limits.

## 7. Submission reconciliation

| Submission requirement | Actual state and required closeout |
| --- | --- |
| Public MIT repository | Connected GitHub metadata reports private and no detected license; root LICENSE lookup at the pinned branch returned 404. Perform the publication/rights/secret review, choose the authorized license, then publish explicitly. No visibility/license change was made here. |
| Dataset location, DOI and access terms | Provide the exact frozen release, source-specific rights, accession/DOI, manifests and access instructions. Do not invent a DOI or relabel all upstream data as MIT. |
| A100 node, GPUs, wall clock and seeds | Fill from the actual completed job/run receipts, not the old CPU environment or a proposed scheduler request. |
| Logs and final checkpoint | Preserve authentic logs and the selected checkpoint with immutable hashes. Current repository policy ignores weights/raw logs. Linked immutable release/model assets are a proposed reconciliation; confirm that they satisfy any literal requirement for committed payloads before marking the row complete. |
| Pi4 latency script and result | The command-WAV smoke is supplied, but real Pi resource and full live-path measurements remain pending. |
| Unseen speakers | A genuinely new human suite is required; the old three-person holdout and already examined tests cannot establish broad fresh generalization. |
| Comparable baseline | Uniform/balanced arms are a same-size sampling comparison, not automatically a different-architecture baseline. Record exact comparator weights, parameter size, data/budget, runtime and same-suite results; recover missing shipping weights rather than substitute another artifact. Clarify a stricter rubric interpretation before checking this off. |

The historical broad suite is not green: 656 passed, 20 failed, 13 skipped and 13
errors, with named failures in `additional-verification.json`. The historical
focused suite's 184 passes and this package's 49 fixture passes are not additive
proof of a fully passing repository. Rerun the full repository with its root
interpreter after integration and report every remaining failure by name.

Historical complete-command results were zero accepted-exact supported commands:
human 0/636 test and 0/83 holdout, synthetic 0/3,368 and 0/100. Numeral-component
accuracy was 449/696 (64.51%). Three-engine agreement on rejected commands does
not establish recognition quality. None of these figures describe a newly completed
A100 candidate whose artifacts have not yet been inspected.

## 8. Integrate and run the delivered service code

The patch changes only the existing worker and adds the smoke runner and two test
files. It contains no weights, audio, provider changes or architecture/training
changes. Use an isolated integration worktree. Preserve all other agents' dirty
work and running jobs. Check the original worker blob, ensure the three added files
are absent, and run `git apply --check` before applying `service-readiness.patch`.
A changed base must be reviewed; do not force a patch over concurrent edits.

```sh
# Run in the isolated repository integration worktree, with the existing root PY.
git hash-object scripts/runtime/speaker_worker.py
# Expected: 944ce510fbe14254ebd72362d11c1987ecd5eead

git apply --check /path/to/service-readiness.patch
git apply /path/to/service-readiness.patch

"$VCM_PY" -m pytest -q -p no:cacheprovider \
  scripts/test/test_speaker_worker_resident.py \
  scripts/test/test_vcm_resident_smoke.py

# Then rerun the existing focused and full repository suites. Do not hide failures.
"$VCM_PY" -m pytest -q -p no:cacheprovider

# Use actual, bound candidate/WAV paths. This neither trains nor installs a model.
"$VCM_PY" -m scripts.test.vcm_resident_smoke \
  --bundle "$CANDIDATE_BUNDLE" --wav "$COMMAND_WAV" \
  --engine ncnn --threads 1 --repeat 3 --run-id "$UNIQUE_SMOKE_RUN_ID"

# Persistent service: WAV/status/mute/shutdown controls on stdin; JSONL on stdout.
"$VCM_PY" -m scripts.runtime.speaker_worker \
  --experimental-intent-slots --engine ncnn --threads 1 \
  --bundle "$CANDIDATE_BUNDLE"
```

A successful smoke says that the bound service ran correctly. Use the existing
`vcm_intent_slots.py evaluate` path and sealed expected outputs for accuracy. Run
already examined sets with `--regression`; fresh test/holdout requires the existing
complete `lock` stage. Do not install a default model or dispatch providers here.
Register the new smoke entry in the project's existing source map as test-only,
and append compact new results to the current experiment report/index during the
reviewed integration. Do not rewrite frozen historical protocols/status receipts.

**Completion condition:** report presentation-ready only after the actual selected
A100 candidate, data/calibration/enrollment bindings, fresh human command suite,
claimed live ownership and physical Pi gates pass, and submission assets are
complete. Until then, retain the exact blocked/failed stages and their evidence.
