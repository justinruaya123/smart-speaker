# VCM finalization package

Read `VCM_FINALIZATION.md` first. `verification.json` records measured scope and
remaining blockers. `final-test-contract.json` is not locked: unapproved
participant/coverage/Pi parameters remain null.

`service-readiness.patch` changes four source/test files against the verified
worker blob at commit `5be3a7f5f5ac38ba6c4fcc14d7fd99de478b0bbd`.
`source/` contains the resulting files for review, not an independent runnable
repository. Do not overwrite concurrent files from this directory.

Apply only after `git apply --check` in an isolated integration worktree and after
checking the original worker blob plus absence of the new paths. Re-run the full
repository suite and the real candidate smoke there. No trained weights, corpus,
cloud credentials, dependency installation or automatic deployment is included.

49 local tests passed, with recognizer doubles. A clean patch roundtrip reproduced
all four tested files byte-for-byte and passed the same 49 tests. This is not an
A100, ncnn accuracy, live ownership, or physical Pi qualification result.

The source changes have not been published to GitHub or applied to the running
A100 job. `SHA256SUMS.txt` covers the delivered files, excluding itself.
